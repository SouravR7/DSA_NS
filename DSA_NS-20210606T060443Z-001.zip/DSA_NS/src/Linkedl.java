public class Linkedl {

}
