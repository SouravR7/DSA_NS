public class Main {
    public static void main(String[] args){
        System.out.println("Hello Home");
        System.out.println("Thank You Intellij IDEA");
    }
}

